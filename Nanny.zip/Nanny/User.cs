﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nanny
{
    public class User
    {
        #region Fields

        private static int lastUserID = 0;

        #endregion

        #region Properties

        public int UserID { get; set; }
        public string UserName { get; set; }
        public string UserAddress { get; set; }
        public string UserEmail { get; set; }

        public virtual ICollection<Review> Reviews { get; set; }

        #endregion

        #region Constructors

        public User()
        {
            UserID = ++lastUserID;
        }

        #endregion
    }
}
