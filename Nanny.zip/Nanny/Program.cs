﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Nanny
{
    class Program
    {
        static void Main(string[] args)
        {
            /*  var x = Factory.CreateUser("Ira", "Woodinville", "snleo32@gmail.com");
              var y = Factory.CreateUser("Sasha", "Redmond", "kokoko@gmail.com");*/

            /* var x = Factory.CreateChildCare("Sarojini", "Bellevue", "Cool");
             var y = Factory.CreateChildCare("Fairyland", "Bellevue", "Not cool");*/

            var x = Factory.RatingUpdate(1, 5);
            var y = Factory.RatingUpdate(1, 4);
            var z = Factory.RatingUpdate(2, 3);
            var a = Factory.RatingUpdate(2, 7);

        }
    }
}
